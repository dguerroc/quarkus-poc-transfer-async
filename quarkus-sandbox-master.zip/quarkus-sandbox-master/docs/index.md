* [Kickstart your first Quarkus application](./01-start.md)
* [Building a Spring web application with Quarkus](./02-spring.md)
* [Interacting with REST APIs ](./restclient.md)
* [Building reactive APIs with Quarkus](./reactive.md)
* [Building GraphQL APIs with Quarkus](./graphql.md)
* [Consuming GraphQL APIs with Quarkus](./graphql-client.md)
* [Integrating Jakarta Data with Quarkus](./jakarta-data.md)

