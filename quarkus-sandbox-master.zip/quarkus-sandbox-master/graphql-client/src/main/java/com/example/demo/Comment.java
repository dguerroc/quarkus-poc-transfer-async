package com.example.demo;

public record Comment(
        String id,
        String content
) {

}
