package com.example.demo;


public record CreatePost(
        String title,
        String content) {

}
