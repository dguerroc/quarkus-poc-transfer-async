package com.example.demo;

public record PostSummary(String title) {
}
