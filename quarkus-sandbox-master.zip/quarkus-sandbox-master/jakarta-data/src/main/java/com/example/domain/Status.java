package com.example.domain;

public enum Status {
    DRAFT, PENDING_MODERATION, PUBLISHED;
}
