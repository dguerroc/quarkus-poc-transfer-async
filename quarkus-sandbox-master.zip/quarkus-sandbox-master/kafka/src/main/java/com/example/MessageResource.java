package com.example;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.reactive.messaging.Channel;
import org.jboss.resteasy.reactive.RestStreamElementType;

import java.util.concurrent.Flow;

@Path("/messages")
@Slf4j
public class MessageResource {
    @Inject
    MessageHandler handler;
    @Inject
    @Channel("messages-stream")
    // Publisher<Message> stream;
    // see: https://github.com/quarkusio/quarkus/issues/35219
    Flow.Publisher<Message> stream;

    @POST
    @Consumes(MediaType.TEXT_PLAIN)
    public void send(String message) {
        log.info("sending: {}", message);
        handler.send(message);
    }

    @GET
    @Produces(MediaType.SERVER_SENT_EVENTS)
    @RestStreamElementType(MediaType.APPLICATION_JSON)
    public Flow.Publisher<Message> stream() {
        return stream;
    }
}
