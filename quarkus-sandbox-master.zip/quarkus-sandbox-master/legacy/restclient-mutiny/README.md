# RestClient Mutiny


quarkus-rest-client-mutiny is missing since 3.9.0.