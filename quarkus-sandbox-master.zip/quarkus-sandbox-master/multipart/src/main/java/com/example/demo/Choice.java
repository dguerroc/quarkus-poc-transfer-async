package com.example.demo;

public enum Choice {
    YES, NO
}
