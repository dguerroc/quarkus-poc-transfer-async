package com.example

data class PostPage(val content: List<Post>, val count: Long)