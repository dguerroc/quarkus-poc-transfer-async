package com.example;

public class PostNotFoundException extends RuntimeException {

}
