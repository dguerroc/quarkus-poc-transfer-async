package com.example;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class NativePostResourceIT extends IntegrationTest {

    // Execute the same tests but in native mode.
}